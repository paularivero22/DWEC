import React, { useContext, useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { AppContext } from "../context/AppContext";

const ExpedienteDetalle = () => {
    const { negocio, usuario, setMensaje } = useContext(AppContext);
    const { id } = useParams();
    const navigate = useNavigate();

    const [expediente, setExpediente] = useState(null);
    const [paciente, setPaciente] = useState(null);
    
    useEffect(() => {
        const cargarDatos = async () => {
            const exp = await negocio.obtenerExpediente(id);
            const pac = await negocio.obtenerPaciente(exp.pacienteId);
            setExpediente(exp);
            setPaciente(pac);
        };
        cargarDatos();
    }, [id, negocio]);

    const handleGuardar = async () => {
        await negocio.actualizarExpediente(expediente);
        setMensaje({ tipo: "success", texto: "Expediente actualizado" });
        navigate("/expedientes");
    };

    if (!usuario || (usuario.tipo !== "medico" && usuario.tipo !== "admin")) {
        return <h2>Acceso denegado</h2>;
    }

    return (
        <div>
            <h1>Expediente de {paciente?.nombre}</h1>
            <textarea value={expediente?.antecedentes || ""} onChange={(e) => setExpediente({ ...expediente, antecedentes: e.target.value })} placeholder="Antecedentes" />
            <textarea value={expediente?.diagnosticos || ""} onChange={(e) => setExpediente({ ...expediente, diagnosticos: e.target.value })} placeholder="Diagnósticos" />
            <textarea value={expediente?.tratamientos || ""} onChange={(e) => setExpediente({ ...expediente, tratamientos: e.target.value })} placeholder="Tratamientos" />
            <textarea value={expediente?.observaciones || ""} onChange={(e) => setExpediente({ ...expediente, observaciones: e.target.value })} placeholder="Observaciones" />
            <button onClick={handleGuardar}>Guardar</button>
            <button onClick={() => navigate("/expedientes")}>Cancelar</button>
        </div>
    );
};

export default ExpedienteDetalle;
