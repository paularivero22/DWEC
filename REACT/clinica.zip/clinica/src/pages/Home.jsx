import React from "react";

const Home = () => {
    return <h1>Bienvenido a la Clínica Salud</h1>;
};

export default Home;
