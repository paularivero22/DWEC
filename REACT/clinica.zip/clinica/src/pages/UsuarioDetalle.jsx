import React, { useContext, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AppContext } from "../context/AppContext";

const UsuarioDetalle = () => {
    const { negocio, usuario, setMensaje } = useContext(AppContext);
    const navigate = useNavigate();
    
    const [nuevoUsuario, setNuevoUsuario] = useState({
        username: "",
        password: "",
        tipo: "gestion",
    });

    const handleGuardar = async () => {
        await negocio.crearUsuario(nuevoUsuario);
        setMensaje({ tipo: "success", texto: "Usuario creado" });
        navigate("/usuarios");
    };

    if (!usuario || usuario.tipo !== "admin") {
        return <h2>Acceso denegado</h2>;
    }

    return (
        <div>
            <h1>Crear Usuario</h1>
            <input type="text" placeholder="Usuario" value={nuevoUsuario.username} onChange={(e) => setNuevoUsuario({ ...nuevoUsuario, username: e.target.value })} />
            <input type="password" placeholder="Contraseña" value={nuevoUsuario.password} onChange={(e) => setNuevoUsuario({ ...nuevoUsuario, password: e.target.value })} />
            <select value={nuevoUsuario.tipo} onChange={(e) => setNuevoUsuario({ ...nuevoUsuario, tipo: e.target.value })}>
                <option value="gestion">Gestión</option>
                <option value="medico">Médico</option>
                <option value="admin">Administrador</option>
            </select>
            <button onClick={handleGuardar}>Guardar</button>
            <button onClick={() => navigate("/usuarios")}>Cancelar</button>
        </div>
    );
};

export default UsuarioDetalle;
