import React, { useContext, useEffect, useState } from "react";
import { AppContext } from "../context/AppContext";
import { Link } from "react-router-dom";

const Expedientes = () => {
    const { negocio, usuario } = useContext(AppContext);
    const [expedientes, setExpedientes] = useState([]);
    const [filtro, setFiltro] = useState("");
    const [pagina, setPagina] = useState(0);

    useEffect(() => {
        const cargarExpedientes = async () => {
            const pacientes = await negocio.obtenerPacientes(filtro, pagina * 10, 10);
            const expedientesConPacientes = await Promise.all(
                pacientes.map(async (paciente) => {
                    const expediente = await negocio.obtenerExpediente(paciente.id);
                    return { ...expediente, nombre: paciente.nombre, telefono: paciente.telefono, seguroMedico: paciente.seguroMedico };
                })
            );
            setExpedientes(expedientesConPacientes);
        };
        cargarExpedientes();
    }, [filtro, pagina, negocio]);

    if (!usuario || (usuario.tipo !== "medico" && usuario.tipo !== "admin")) {
        return <h2>Acceso denegado</h2>;
    }

    return (
        <div>
            <h1>Gestión de Expedientes</h1>
            <input
                type="text"
                placeholder="Buscar expediente..."
                value={filtro}
                onChange={(e) => setFiltro(e.target.value)}
            />
            <ul>
                {expedientes.map((e) => (
                    <li key={e.id}>
                        {e.nombre} - {e.seguroMedico} - {e.telefono}
                        <Link to={`/expedientes/${e.id}`}>Ver expediente</Link>
                    </li>
                ))}
            </ul>
            <button disabled={pagina === 0} onClick={() => setPagina(pagina - 1)}>Anterior</button>
            <button onClick={() => setPagina(pagina + 1)}>Siguiente</button>
        </div>
    );
};

export default Expedientes;
