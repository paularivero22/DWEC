import React, { useContext, useEffect, useState } from "react";
import { AppContext } from "../context/AppContext";

const Pacientes = () => {
    const { negocio, usuario } = useContext(AppContext);
    const [pacientes, setPacientes] = useState([]);
    const [filtro, setFiltro] = useState("");
    const [pagina, setPagina] = useState(0);

    useEffect(() => {
        const cargarPacientes = async () => {
            const datos = await negocio.obtenerPacientes(filtro, pagina * 10, 10);
            setPacientes(datos);
        };
        cargarPacientes();
    }, [filtro, pagina, negocio]);

    if (!usuario || (usuario.tipo !== "gestion" && usuario.tipo !== "admin")) {
        return <h2>Acceso denegado</h2>;
    }

    return (
        <div>
            <h1>Gestión de Pacientes</h1>
            <input
                type="text"
                placeholder="Buscar paciente..."
                value={filtro}
                onChange={(e) => setFiltro(e.target.value)}
            />
            <ul>
                {pacientes.map((p) => (
                    <li key={p.id}>
                        {p.nombre} - {p.dni}
                        <button onClick={() => negocio.eliminarPaciente(p.id)}>Eliminar</button>
                    </li>
                ))}
            </ul>
            <button disabled={pagina === 0} onClick={() => setPagina(pagina - 1)}>Anterior</button>
            <button onClick={() => setPagina(pagina + 1)}>Siguiente</button>
        </div>
    );
};

export default Pacientes;
