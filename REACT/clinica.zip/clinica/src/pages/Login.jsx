import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AppContext } from "../context/AppContext";

const Login = () => {
    const { logIn } = useContext(AppContext);
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const navigate = useNavigate();

    const handleSubmit = (event) => {
        event.preventDefault();
        const user = logIn(username, password);
        if (user) {
            navigate("/");
        } else {
            alert("Credenciales incorrectas");
        }
    };

    return (
        <div>
            <h1>Iniciar Sesion</h1>
            <form onSubmit={handleSubmit}>
                <input type="text" placeholder="Usuario" value={username} onChange={(event) => setUsername(event.target.value)} />
                <input type="password" placeholder="Contraseña" value={password} onChange={(event) => setPassword(event.target.value)} />
                <button type="submit">Ingresar</button>
            </form>
        </div>
    );
};

export default Login;
