import React from "react";

const NotFound = () => {
    return <h1>Pagina no encontrada</h1>;
};

export default NotFound;
