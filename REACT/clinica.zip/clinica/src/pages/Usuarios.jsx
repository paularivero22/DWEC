import React, { useContext, useEffect, useState } from "react";
import { AppContext } from "../context/AppContext";
import { Link } from "react-router-dom";

const Usuarios = () => {
    const { negocio, usuario } = useContext(AppContext);
    const [usuarios, setUsuarios] = useState([]);

    useEffect(() => {
        const cargarUsuarios = async () => {
            const datos = await negocio.obtenerUsuarios();
            setUsuarios(datos);
        };
        cargarUsuarios();
    }, [negocio]);

    if (!usuario || usuario.tipo !== "admin") {
        return <h2>Acceso denegado</h2>;
    }

    return (
        <div>
            <h1>Gestión de Usuarios</h1>
            <Link to="/usuarios/nuevo">Crear Usuario</Link>
            <ul>
                {usuarios.map((user) => (
                    <li key={user.id}>
                        {user.username} - {user.tipo}
                        <button onClick={() => negocio.eliminarUsuario(user.id)}>Eliminar</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Usuarios;
