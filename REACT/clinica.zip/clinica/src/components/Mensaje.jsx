import React, { useContext } from "react";
import { AppContext } from "../context/AppContext";

const Mensaje = () => {
    const { mensaje, setMensaje } = useContext(AppContext);

    if (!mensaje) {
        return null;
    }

    //oculta el mensaje después de 3s
    setTimeout(() => setMensaje(null), 3000);

    return <div className={`mensaje ${mensaje.tipo}`}>{mensaje.texto}</div>;
};

export default Mensaje;
