import React from "react";

const Footer = () => {
    return <footer>Clinica Salud - Paula Rivero</footer>;
};

export default Footer;
