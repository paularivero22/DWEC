import { Link } from "react-router-dom";
import { useContext } from "react";
import { AppContext } from "../context/AppContext";

const Navbar = () => {
  const { usuario } = useContext(AppContext);

  return (
    <nav>
      <ul>
        <li><Link to="/">Inicio</Link></li>
        {usuario ? (
          <>
            {usuario.tipo === "admin" && <li><Link to="/usuarios">Usuarios</Link></li>}
            {usuario.tipo !== "medico" && <li><Link to="/pacientes">Pacientes</Link></li>}
            {(usuario.tipo === "medico" || usuario.tipo === "admin") && (
              <li><Link to="/expedientes">Expedientes</Link></li>
            )}
            <li><button id="cerrarSesion">Cerrar sesión</button></li>
          </>
        ) : (
          <li><Link to="/login">Login</Link></li>
        )}
      </ul>
    </nav>
  );
};

export default Navbar;
