import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";
import Home from "./pages/Home";
import Pacientes from "./pages/Pacientes";
import Expedientes from "./pages/Expedientes";
import Usuarios from "./pages/Usuarios";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";
import { AppProvider } from "./context/AppContext";

function App() {
    return (
        <AppProvider>
            <Router>
                <Layout>
                    <Routes>
                        <Route path="/" element={<Home />} />
                        <Route path="/pacientes" element={<Pacientes />} />
                        <Route path="/expedientes" element={<Expedientes />} />
                        <Route path="/usuarios" element={<Usuarios />} />
                        <Route path="/login" element={<Login />} />
                        <Route path="*" element={<NotFound />} />
                    </Routes>
                </Layout>
            </Router>
        </AppProvider>
    );
}

export default App;
